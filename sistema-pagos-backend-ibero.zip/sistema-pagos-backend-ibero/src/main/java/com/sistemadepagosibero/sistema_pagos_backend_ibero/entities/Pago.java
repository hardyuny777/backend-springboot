package com.sistemadepagosibero.sistema_pagos_backend_ibero.entities;

import java.time.LocalDate;

import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.PagoStatus;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.TypePago;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

//Anotación que indica que esta clase es una entidad JPA
@Entity

//Anotación de lombok que proporciona un patron Builder
@Builder

//Anotación de lombok que genera getters, setters, equals, hashCode y ToString
@Data

//Anotacion de lombok que genera un constructor sin argumentos
@NoArgsConstructor

//Anotacion de lombok que genera un constructor con todos los argumentos
@AllArgsConstructor


// Definimos la entidad Pago que representa un registro de un pago en la base de datos.

public class Pago {


    // Indicamos que el campo 'id' será la clave primaria de esta entidad.
    @Id


    // Especificamos que el valor de 'id' se generará automáticamente usando la estrategia de identidad (auto-incremental).

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    // Fecha en la que se realiza el pago
    private LocalDate fecha;

    // Monto o cantidad de dinero pagada.
    private double cantidad;

    // Tipo de pago (efectivo, tarjeta, transferencia, etc.), definido por un enumerado 'TypePago'.
    private TypePago type;

    // Estado actual del pago (por ejemplo: pendiente, completado, fallido), definido en 'PagoStatus'.
    private PagoStatus status;

    // Ruta o nombre del archivo asociado al pago (puede ser un comprobante, recibo, etc.).
    private String file;
    
    // Relación muchos-a-uno: varios pagos pueden pertenecer a un solo estudiante.
    @ManyToOne
    private Estudiante estudiante;
    
}
