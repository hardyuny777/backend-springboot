package com.sistemadepagosibero.sistema_pagos_backend_ibero.entities;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


//Anotación que indica que esta clase es una entidad JPA
@Entity

//Anotación de lombok que proporciona un patron Builder
@Builder

//Anotación de lombok que genera getters, setters, equals, hashCode y ToString
@Data

//Anotacion de lombok que genera un constructor sin argumentos
@NoArgsConstructor

//Anotacion de lombok que genera un constructor con todos los argumentos
@AllArgsConstructor

//Definicion de la clase estudiante
public class Estudiante {

    //Indicar que este campo es la primary key en la base de datos
    @Id  

    //Identificador unico del estudiante
    private String id;

    //Nombre del estudiante
    private String nombre;

    //Apellido del estudiante
    private String apellido;
    

    //Anotacion que indica que este campo debe ser unico en la base de datos
    @Column(unique = true)

    //Codigo unico del estudiante
    private String codigo;

    //Identificador del programa academico al que pertenece el estudiante
    private String programaId;

    //URL o ruta de la foto del estudiante
    private String foto;

   
    
}
