package com.sistemadepagosibero.sistema_pagos_backend_ibero.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistemadepagosibero.sistema_pagos_backend_ibero.entities.Estudiante;

@Repository

//Linea que permite conectarnos con clase Estudiante
public interface EstudianteRepository extends JpaRepository<Estudiante, String> {

    //Método personalizado

    Estudiante findByCodigo(String codigo);


    //Metodo personalizado  que muestre una lista  de estudiantes que pertenecen a un programa en especifico

    List<Estudiante> findByProgramaId(String programaId);
    
}
