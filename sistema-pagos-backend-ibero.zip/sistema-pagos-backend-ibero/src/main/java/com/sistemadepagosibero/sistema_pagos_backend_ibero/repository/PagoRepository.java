package com.sistemadepagosibero.sistema_pagos_backend_ibero.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sistemadepagosibero.sistema_pagos_backend_ibero.entities.Pago;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.PagoStatus;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.TypePago;


/**
 * Interface que define el repositorio para manejar las operaciones de la entidad 'Pago'.
 * Extiende JpaRepository para permitir el acceso a datos de pagos en la base de datos.
 */
@Repository

public interface PagoRepository extends JpaRepository<Pago, Long>{

    //Metodo personalizado para buscar pagos por un estudiante en especifico

    List<Pago> findByEstudianteCodigo(String codigo);

    //Metodo personalizado para buscar los pagos por su estado CREADO VALIDADO RECHAZADO

    List<Pago> findByStatus(PagoStatus status);

    //Metodo personalizado para buscar pagos por su tipo EFECTIVO, CHEQUE, TRANSFERENCIA, DEPOSITO


    List<Pago> findByType(TypePago type);
     //Busca todos los pagos realizados con un tipo específico de pago.

    
}
