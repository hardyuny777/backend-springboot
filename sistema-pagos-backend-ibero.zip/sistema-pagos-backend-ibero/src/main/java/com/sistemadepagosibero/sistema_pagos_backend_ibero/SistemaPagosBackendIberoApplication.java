package com.sistemadepagosibero.sistema_pagos_backend_ibero;

import java.time.LocalDate;
import java.util.Random;
import java.util.UUID;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.sistemadepagosibero.sistema_pagos_backend_ibero.entities.Estudiante;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.entities.Pago;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.PagoStatus;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.TypePago;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.repository.EstudianteRepository;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.repository.PagoRepository;

@SpringBootApplication
public class SistemaPagosBackendIberoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaPagosBackendIberoApplication.class, args);
	}




    @Bean
	CommandLineRunner commandLineRunner(EstudianteRepository estudianteRepository, PagoRepository pagoRepository){
		return args -> {
			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Junior")
			.apellido("Arboleda")
			.codigo("1234")
			.programaId("IS123")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Mark")
			.apellido("Thompson")
			.codigo("5678")
			.programaId("ID456")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Andres")
			.apellido("Cepeda")
			.codigo("6789")
			.programaId("LC789")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Tomas")
			.apellido("Perez")
			.codigo("4321")
			.programaId("IA321")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Karen")
			.apellido("Osorio")
			.codigo("2143")
			.programaId("IE213")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Astrix")
			.apellido("Example")
			.codigo("4123")
			.programaId("MP312")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Patrick")
			.apellido("Example")
			.codigo("8765")
			.programaId("PE654")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Herbin")
			.apellido("Example")
			.codigo("6785")
			.programaId("LD546")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Sara")
			.apellido("Landry")
			.codigo("7658")
			.programaId("IC465")
			.build());

			// Guarda un estudiante en la base de datos al iniciar la app
			estudianteRepository.save(Estudiante.builder()
			.id(UUID.randomUUID().toString())
			.nombre("Louis")
			.apellido("Smith")
			.codigo("4576")
			.programaId("PS564")
			.build());


			//OBTIENE TODOS LOS VALORES POSIBLES ENUMERADOS TYPE PAGO

			TypePago tiposPago[] = TypePago.values();

			//Crea un objeto random para seleccionar valores aleatorios

			Random random = new Random();



			//itera sobre todos los estudiantes del repository

			estudianteRepository.findAll().forEach(estudiante -> {
				//Crear 10 pagos para cada estudiante
				for(int i=0; i<10; i++){
					//Genere un index aleatorio
					int index = random.nextInt(tiposPago.length);


					Pago pago = Pago.builder()
					.cantidad(1000 + (int) (Math.random()*20000))
					.type(tiposPago[index])
					.status(PagoStatus.CREADO)
					.fecha(LocalDate.now())
					.estudiante(estudiante)
					.build();

					//Guardar el pago en la bd
					pagoRepository.save(pago);
					
				}
			});

			

		};

	}

}





	