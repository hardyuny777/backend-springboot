package com.sistemadepagosibero.sistema_pagos_backend_ibero.services;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.sistemadepagosibero.sistema_pagos_backend_ibero.entities.Estudiante;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.entities.Pago;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.PagoStatus;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.TypePago;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.repository.EstudianteRepository;
import com.sistemadepagosibero.sistema_pagos_backend_ibero.repository.PagoRepository;

import jakarta.transaction.Transactional;

@Service


@Transactional //Para Asegurar que los métodos de esta clase se ejecuten dentro de una 
 //transacción

public class PagoService {

    //Inyeccion de depedencias de PagoRepository para interactuar con la base de datos de pagos

    @Autowired

    private PagoRepository pagoRepository;

    //Inyeccion de depedencias de EstudianteRepository para obtener información de los estudiantes desde la base de datos
    @Autowired
    private EstudianteRepository estudianteRepository;
    
    
    
    /**
     * metodo para guardar el pago en la bd y almacenar un file/archivo pdf en el servidor
     * 
     * @param file     archivo pdf que se subira al servidor
     * @param cantidad  monto del pago realizado    
     * @param type tipo de pago EFECTIVO, CHEQUE, TRANSFERENCIA, DEPOSITO
     * @param date Fecha en la que se realiza pago
     * @param  codigoEstudiante codigo del estudiante que realiza el pago
     * @return objeto Pago guardado en la bd
     * @throws IOException excepsion lanzada si ocurre un error al manejar el file
     */

     public Pago savePago(MultipartFile file, double cantidad, TypePago type, LocalDate date, String codigoEstudiante) 
            throws IOException{


        /**
         * Contruir la ruta donde se guardara el archivo dentro del sistema
         *  System.getProperty("user.home"): Obtiene la ruta del directorio personal del usuario del actual sistema operativo
         * Paths.get: Construir una ruta dentro del directorio personal en la carpeta "enset-data/pagos"
         */

        Path folderPath = Paths.get(System.getProperty("user.home"), "Enset-data", "pagos");


        //Verificar si la carpeta ya existe, si no la debe crear
        if (!Files.exists(folderPath)){
            Files.createDirectories(folderPath);
        }

        //Generamos un nombre unico para el archivo usando el UUID (Identificador unico universal)

        String fileName = UUID.randomUUID().toString();

        //CONSTRUIMOS LA RUTA COMPLETA DEL ARCHIVO AGREGANDO LA EXTENSION  .PDF 

        Path filePath = Paths.get(System.getProperty("user.home"), "Enset-data", "pagos", fileName + ".pdf");

        //Guardamos el archivo recibido en la ubicación  especificada dentro del sistema de archivos

        Files.copy(file.getInputStream(), filePath);

        //Buscamos el estudiante que realiza el pago con su codigo

        Estudiante estudiante = estudianteRepository.findByCodigo(codigoEstudiante);

        //Creamos un nuevo objeto Pago utilizando el patron de diseño Builder 

        Pago pago = Pago.builder()
        .type(type)
        .status(PagoStatus.CREADO) //estado inicial del pago
        .fecha(date)
        .estudiante(estudiante)
        .cantidad(cantidad)
        .file(filePath.toUri().toString())
             .build(); //Construcción final del objeto Pago



         return pagoRepository.save(pago);



     }



     public byte[] getArchivoPorId(PagoStatus status, Long pagoId) throws IOException {

        //busca un objeto  en la base de datos por su ID
        Pago pago = pagoRepository.findById(pagoId).get();


        /**pago.getFile: Obtiene la URI  del archivo guardado como una cadena  de texto
         * URI.create: convierte la cadena de texto en un objeto URI
         * pathOf: Convierte la URI en un path para poder acceder al archivo 
         * Files.readAllBytes: Lee el contenido del archivo y  lo va a devolver en un array 
         * vector de bytes 
         * Esto permitir obtener el contenido del archivo para su posterior uso por ejemplo
         * descargarlo
         * 
         */



        return Files.readAllBytes(Path.of(URI.create(pago.getFile())));  


    }

    public Pago actualizarPagoPorStatus(PagoStatus status, Long Id){

    //busca un objeto  en la base de datos por su ID
     Pago pago = pagoRepository.findById(Id).get();



    //Actualiza el estado del pago (VALIDADO O RECHAZADO)
        pago.setStatus(status);


    //Guarda el objeto pago Actualizado en la bd y lo devuelve

        return pagoRepository.save(pago);


     }



}
