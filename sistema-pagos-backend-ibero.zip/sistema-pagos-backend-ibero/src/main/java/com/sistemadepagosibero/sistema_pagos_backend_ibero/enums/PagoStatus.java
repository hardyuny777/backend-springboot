package com.sistemadepagosibero.sistema_pagos_backend_ibero.enums;

/**
 * Enumeración que define los posibles estados de un pago en el sistema.
 * Los valores representan el ciclo de vida de un pago y su validación.
 */

public enum PagoStatus {

    CREADO, VALIDADO, RECHAZADO
    
}
