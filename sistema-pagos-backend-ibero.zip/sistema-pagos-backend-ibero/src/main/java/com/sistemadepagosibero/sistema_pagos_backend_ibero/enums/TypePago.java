package com.sistemadepagosibero.sistema_pagos_backend_ibero.enums;

/**
 * Enumeración que define los tipos de métodos de pago disponibles en el sistema.
 * Cada valor representa un método específico de pago utilizado por los usuarios.
 */

public enum TypePago {

    EFECTIVO, CHEQUE, TRANSFERENCIA, DEPOSITO

}
