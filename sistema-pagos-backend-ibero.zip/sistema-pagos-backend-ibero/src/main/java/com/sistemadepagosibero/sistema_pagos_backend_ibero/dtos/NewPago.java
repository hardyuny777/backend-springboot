package com.sistemadepagosibero.sistema_pagos_backend_ibero.dtos;

import java.time.LocalDate;

import com.sistemadepagosibero.sistema_pagos_backend_ibero.enums.TypePago;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//Aqui se muestra las librerias importadas


//Anotacion de lombok que genera un constructor con todos los argumentos
@AllArgsConstructor

//Anotacion de lombok que genera un constructor sin argumentos
@NoArgsConstructor

//Anotación de lombok que genera getters, setters, equals, hashCode y ToString
@Data

public class NewPago {

    //Cantidad de dinero pagada
    private double cantidad;

    //Tipo de pago
    private TypePago typePago;

    //Esto permite identificar la fecha del pago
    private LocalDate date;

    //Codigo del estudiante
    private String codigoEstudiante;
    
}
